from fastapi import APIRouter
from app.services.metrics_service import get_dashboard_metrics

router = APIRouter()

@router.get("/api/dashboard/full")
def dashboard_full():
    metrics = get_dashboard_metrics()

    return {
        "overview": {
            "protected_endpoints": 2847,
            "pqc_handshakes_hr": metrics["total_handshakes_hr"],
            "active_policies": 5,
            "avg_latency": metrics["avg_latency"],
            "success_rate": metrics["success_rate"],
            "systems_status": "ALL SYSTEMS NOMINAL"
        },
        "performance": {
            "p50_latency": metrics["p50_latency"],
            "p99_latency": metrics["p99_latency"],
            "failure_rate": metrics["failure_rate"]
        },
        "algorithm_distribution": metrics["algorithm_distribution"]
    }