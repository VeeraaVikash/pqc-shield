from fastapi import APIRouter
from app.database import SessionLocal
from app.models.alert_models import Alert

router = APIRouter()

@router.get("/api/alerts")
def get_alerts():
    db = SessionLocal()
    alerts = db.query(Alert).order_by(Alert.timestamp.desc()).limit(20).all()

    result = []
    for a in alerts:
        result.append({
            "type": a.type,
            "message": a.message,
            "severity": a.severity,
            "timestamp": a.timestamp
        })

    db.close()
    return result